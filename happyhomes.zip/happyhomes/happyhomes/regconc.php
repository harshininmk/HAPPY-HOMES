<?php
    $servername="localhost";
    $username="root";
    $password="";
    $db_name="happyhomes";
    $conn = mysqli_connect($servername, $username, $password, $db_name);
    if(!$conn)
  {
    die ("Error deleting record:" );
  }
  if(isset($_POST['submit']))
  {
   $fullname=$_POST['fullname'];
   $username=$_POST['username'];
   $email=$_POST['email'];
   $phonenumber=$_POST['phonenumber'];
   $password=$_POST['password'];
   $gender= $_POST['gender']??'';
 
 
   $sql= "INSERT INTO reg (fullname, username, email, phonenumber, password,gender) VALUES ('$fullname', '$username', '$email', '$phonenumber', '$password','$gender')";
 
   if(mysqli_query($conn,$sql)){
     echo "<script>alert('registered sucessfull')</script>";
   }
   else
   {
     echo "error:".mysqli_error($conn);
  }
 
 }

?>